#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <signal.h>
#include <stdint.h>
#include <syslog.h>

#include "yourfile.h"
#include "log.h"


int main(int argc, char **argv)
{
	LOG("Helloworld service started\n");

		do{
			LOG("Hello! This in infinite Helloworld! Stop me if you can!\n");
			usleep(3000000);
		}while(1);

	LOG("Helloworld service stopped\n");

	return 0;
}
