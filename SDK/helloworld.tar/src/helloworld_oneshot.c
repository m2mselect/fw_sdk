#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>	// some headers
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdint.h>
#include <syslog.h>

#include "yourfile.h"
#include "log.h"

int main(int argc, char **argv)
{
	LOG("Hi! This is oneshot HELLO\n");
	return 0;
}
