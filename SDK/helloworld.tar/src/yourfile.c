#include "yourfile.h"


int OneUselessFunc()
{
	return 0;
}